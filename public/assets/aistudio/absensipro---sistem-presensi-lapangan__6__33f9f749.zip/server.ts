import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// Storage directory for persistent real-time state
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

interface ServerDb {
  employees: Record<string, unknown>[];
  projects: Record<string, unknown>[];
  logs: Record<string, unknown>[];
  deletedLogs: Array<{ userId: string; tanggal: string; jamMasuk?: string; id?: string }>;
  adminPin: string;
  companyName: string;
  lastUpdated: number;
}

let dbState: ServerDb = {
  employees: [],
  projects: [],
  logs: [],
  deletedLogs: [],
  adminPin: '1234',
  companyName: 'PT Konstruksi Pratama Mandiri',
  lastUpdated: Date.now(),
};

// Load saved state from disk if exists
try {
  if (fs.existsSync(DB_FILE)) {
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    dbState = { ...dbState, ...parsed };
    if (!Array.isArray(dbState.deletedLogs)) {
      dbState.deletedLogs = [];
    }
  }
} catch (e) {
  console.warn('Failed to load db.json, using defaults:', e);
}

function persistDb() {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(dbState, null, 2), 'utf-8');
  } catch (e) {
    console.warn('Failed to write db.json:', e);
  }
}

// SSE Clients Set for Real-Time Broadcast to all devices
const sseClients = new Set<Response>();

function broadcastRealtimeUpdate(type: string, data: unknown) {
  const payload = JSON.stringify({ type, data, timestamp: Date.now() });
  for (const client of sseClients) {
    try {
      client.write(`data: ${payload}\n\n`);
    } catch {
      sseClients.delete(client);
    }
  }
}

// 1. Real-Time Server-Sent Events (SSE) Stream
app.get('/api/realtime', (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  // Send initial state upon connection
  res.write(`data: ${JSON.stringify({ type: 'connected', data: dbState })}\n\n`);
  sseClients.add(res);

  req.on('close', () => {
    sseClients.delete(res);
  });
});

// 2. GET sync state
app.get('/api/sync', (_req: Request, res: Response) => {
  res.json({
    status: 'success',
    ...dbState,
  });
});

// 3. POST sync updates (Real-time update triggered by any device)
function cleanDateStr(val: unknown): string {
  if (!val || val === '-') return '';
  const str = String(val).trim().replace(/^'/, '');
  const m = str.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
  if (m) return `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`;
  const dmy = str.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})/);
  if (dmy) return `${dmy[3]}-${dmy[2].padStart(2, '0')}-${dmy[1].padStart(2, '0')}`;
  return str;
}

function cleanTimeStr(val: unknown): string {
  if (!val || val === '-') return '-';
  const str = String(val).trim().replace(/^'/, '');
  const m = str.match(/(\d{1,2}):(\d{2})/);
  if (m) return `${m[1].padStart(2, '0')}:${m[2]}`;
  return str;
}

app.post('/api/sync', (req: Request, res: Response) => {
  try {
    const body = req.body || {};
    const { action } = body;

    if (action === 'hapus_absen') {
      const targetId = body.id ? String(body.id).trim() : '';
      const targetUser = body.userId ? String(body.userId).trim().toUpperCase() : '';
      const targetTgl = cleanDateStr(body.tanggal);
      const targetJam = cleanTimeStr(body.jamMasuk);

      if (!Array.isArray(dbState.deletedLogs)) {
        dbState.deletedLogs = [];
      }
      dbState.deletedLogs.push({
        id: targetId,
        userId: targetUser,
        tanggal: targetTgl,
        jamMasuk: targetJam,
      });

      dbState.logs = dbState.logs.filter((l) => {
        if (targetId && String(l.id).trim() === targetId) return false;
        const lUser = String(l.userId || '').trim().toUpperCase();
        const lTgl = cleanDateStr(l.tanggal);
        const lJam = cleanTimeStr(l.jamMasuk);
        if (targetUser && targetTgl && lUser === targetUser && lTgl === targetTgl) {
          if (!targetJam || targetJam === '-' || lJam === targetJam || lJam === '-') {
            return false;
          }
        }
        return true;
      });

      dbState.lastUpdated = Date.now();
      persistDb();

      // PENTING: Hanya siarkan event penghapusan absensi ke perangkat lain, JANGAN pernah menyentuh daftar karyawan
      broadcastRealtimeUpdate('log_deleted', {
        id: targetId,
        userId: targetUser,
        tanggal: targetTgl,
        jamMasuk: targetJam,
        logs: dbState.logs,
        deletedLogs: dbState.deletedLogs,
      });

      return res.json({ status: 'success', lastUpdated: dbState.lastUpdated, logs: dbState.logs });
    }

    if (action === 'absen') {
      const existingIdx = (dbState.logs as Array<{ userId: string; tanggal: string }>).findIndex(
        (l) => l.userId?.toUpperCase() === String(body.userId).toUpperCase() && l.tanggal === body.tanggal
      );

      if (existingIdx >= 0) {
        dbState.logs[existingIdx] = {
          ...dbState.logs[existingIdx],
          ...body,
        };
      } else {
        dbState.logs.unshift({
          id: `LOG-SRV-${Date.now()}`,
          ...body,
          createdAt: Date.now(),
        });
      }

      dbState.lastUpdated = Date.now();
      persistDb();
      broadcastRealtimeUpdate('logs_updated', dbState.logs);
      return res.json({ status: 'success', lastUpdated: dbState.lastUpdated });
    }

    if (action === 'daftar_karyawan') {
      const rawTgl = body.tglLahir ? String(body.tglLahir).trim() : '';
      let cleanTgl = rawTgl;
      const isoM = rawTgl.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
      if (isoM) {
        cleanTgl = `${isoM[3].padStart(2, '0')}-${isoM[2].padStart(2, '0')}-${isoM[1]}`;
      }

      const emp = {
        id: body.id,
        nama: body.nama,
        nik: body.nik,
        tglLahir: cleanTgl,
        dept: body.dept,
        jabatan: body.jabatan,
        phone: body.phone,
        fotoKtp: body.fotoKtp,
        fotoKk: body.fotoKk,
        fotoSelfie: body.fotoSelfie,
        statusAktif: body.statusAktif !== 'Nonaktif',
        izinBebasLokasi: body.izinBebasLokasi === 'Ya',
        registeredAt: Date.now(),
      };

      const existingEmpIdx = dbState.employees.findIndex((e) => String(e.id).toUpperCase() === String(emp.id).toUpperCase());
      if (existingEmpIdx >= 0) {
        dbState.employees[existingEmpIdx] = emp;
      } else {
        dbState.employees.push(emp);
      }

      dbState.lastUpdated = Date.now();
      persistDb();
      broadcastRealtimeUpdate('employees_updated', dbState.employees);
      return res.json({ status: 'success', lastUpdated: dbState.lastUpdated });
    }

    if (action === 'sync_employees') {
      if (Array.isArray(body.employees) && body.employees.length > 0) {
        dbState.employees = body.employees;
        dbState.lastUpdated = Date.now();
        persistDb();
        broadcastRealtimeUpdate('employees_updated', dbState.employees);
      }
      return res.json({ status: 'success', lastUpdated: dbState.lastUpdated });
    }

    if (action === 'sync_projects') {
      if (Array.isArray(body.projects) && body.projects.length > 0) {
        dbState.projects = body.projects;
        dbState.lastUpdated = Date.now();
        persistDb();
        broadcastRealtimeUpdate('projects_updated', dbState.projects);
      }
      return res.json({ status: 'success', lastUpdated: dbState.lastUpdated });
    }

    if (action === 'update_settings') {
      if (body.adminPin) dbState.adminPin = String(body.adminPin).trim();
      if (body.companyName) dbState.companyName = String(body.companyName).trim();
      dbState.lastUpdated = Date.now();
      persistDb();
      broadcastRealtimeUpdate('settings_updated', { adminPin: dbState.adminPin, companyName: dbState.companyName });
      return res.json({ status: 'success', lastUpdated: dbState.lastUpdated });
    }

    res.json({ status: 'success', lastUpdated: dbState.lastUpdated });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Sync error';
    res.status(500).json({ status: 'error', message: msg });
  }
});

// Setup Vite Dev Middleware or Static Production Serving
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[AbsensiPro Server] Running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
