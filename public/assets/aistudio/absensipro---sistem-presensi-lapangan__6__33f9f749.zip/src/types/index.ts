export type ShiftScheme = '1_SHIFT' | '2_SHIFT' | '3_SHIFT';

export interface ShiftConfig {
  id: string;
  nama: string; // Contoh: "Shift 1 (Pagi)", "Shift 2 (Sore)", "Shift 3 (Malam)"
  jamMasuk: string; // "07:00"
  jamPulang: string; // "15:00"
  toleransi: number; // menit, contoh: 15
  minJamKerja: number; // jam, contoh: 7
}

export interface Project {
  id: string;
  nama: string;
  lat: number;
  lng: number;
  radius: number; // dalam meter
  shiftScheme: ShiftScheme; // 1_SHIFT, 2_SHIFT, 3_SHIFT
  shifts: ShiftConfig[];
  statusAktif?: boolean; // true = Aktif, false = Nonaktif (hanya proyek aktif yg dapat dipilih)
  // Kompatibilitas mundur
  jamMasuk?: string;
  toleransi?: number;
  minJamKerja?: number;
  shiftType?: string;
}

export interface Employee {
  id: string; // Contoh: ABC010190
  nama: string;
  nik: string; // 16 digit angka KTP
  tglLahir: string; // YYYY-MM-DD
  dept: string;
  jabatan: string;
  phone?: string;
  fotoKtp: string; // URL Google Drive, Base64 Image, atau Base64 PDF
  fotoKtpType?: 'image' | 'pdf';
  fotoKtpName?: string;
  fotoKk: string; // URL Google Drive, Base64 Image, atau Base64 PDF
  fotoKkType?: 'image' | 'pdf';
  fotoKkName?: string;
  fotoSelfie: string; // URL Google Drive atau Base64 lokal
  registeredAt?: number;
  statusAktif?: boolean; // true = Aktif, false = Nonaktif (hanya karyawan aktif yg bisa absen)
  izinBebasLokasi?: boolean; // true = bisa absen di mana saja tanpa batasan radius proyek
}

export interface AttendanceLog {
  id: string;
  userId: string;
  nama: string;
  proyek: string;
  proyekId?: string;
  shiftNama?: string; // Nama shift yang diambil
  tanggal: string; // YYYY-MM-DD
  jamMasuk: string; // "07:55"
  jamPulang: string; // "17:05" or "-"
  status: 'Hadir' | 'Terlambat' | 'Pulang Cepat' | 'Koreksi Admin';
  fotoMasuk?: string | null;
  fotoPulang?: string | null;
  durasiJam?: number; // total jam kerja
  keterangan?: string;
  userLat?: number;
  userLng?: number;
  jarakMeter?: number;
  isBebasLokasi?: boolean;
  createdAt: number;
}

export interface AppSettings {
  companyName: string; // Nama perusahaan pengguna (dapat diatur di admin)
  gasUrl: string;
  adminPin: string; // PIN Admin (Default 1234 saat pertama kali)
  enableVoice: boolean;
  theme?: 'light' | 'dark';
  viewMode?: 'responsive' | 'desktop' | 'mobile';
}
